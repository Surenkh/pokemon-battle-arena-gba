# Pokémon Battle Arena v1.5.0 — Starter Mobility

Pikachu gains **Volt Step**: double tap Left or Right for a committed twelve-stamina
dash. Squirtle gains **Shell Roll**: Down plus a horizontal direction adds movement
to the ordinary dodge for twenty total stamina. Both have visible elemental cues,
interruptible movement, recovery and Practice Technique lessons.

Both moves work for either player in one-window Local Versus. Air Brake and
Shadow Burst remain included. Rival Cup, thirteen fighters, five locations,
Arcade, mastery, audio settings and compatible saves are retained. The title
version and primary GitHub download links now identify v1.5.0.

Open the ROM in mGBA. Local Versus requires the included Lua adapter and an mGBA
0.11 development build; ordinary solo controls work without that adapter.
See FIGHTER_TECHNIQUES.md and LOCAL_VERSUS.md in the player ZIP.

Validation covers host combat/technique boundaries, native lessons, both
Versus sides, pause/retry, save isolation and the full native regression.
The release package requires zero missed display frames and a byte-identical
independent clean rebuild. The validation report records the measured results.

Physical keyboard/Qt/controller sessions, human technique readability and human
matchup balance remain unverified. This release was reconstructed from merged
v1.4 source after the earlier chat's unpushed working files proved inaccessible;
its evidence comes from fresh tests of this build.
