# Pokémon Battle Arena v1.6.0 — Rival Cup

**Choose both challengers.** Each Cup now has three candidates. Scout their
fighters, arenas and counters, win two distinct matchups, then face the Captain.
Cinder, Rook and Wisp join the three Cups as selectable rivals.

**Read the Captain.** Rex closes in for fast melee and follow-ups. Brick
guards and counterattacks. Ren creates space for Aura Pulse. Each Captain has
a scouting cue and fights under the normal combat rules.

**Collect Cup crests.** Earn the Bolt, Shield or Moon crest by winning a Cup.
Crests display by difficulty on the Cup board. Earlier clears qualify when
you open the ROM with your existing save. Style, perfect and best-time
records carry forward.

Open the ROM in mGBA and choose **Rival Cup**. The Player ZIP includes the
Cup guide, the full controls and the Local Versus adapter. Automated emulator
runs cleared all three Cups and verified the crests after a power cycle.
Human difficulty and physical GBA hardware await playtesting.
