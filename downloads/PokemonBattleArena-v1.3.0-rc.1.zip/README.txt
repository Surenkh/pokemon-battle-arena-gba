FIGHTER TECHNIQUES PREVIEW
Jigglypuff: tap Up again during descent for Air Brake (8 stamina).
Gastly: B casts Shadow Orb; a fresh B arms its delayed burst (8 extra stamina).
Practice > Training > Technique teaches both moves. Select retries quickly.
With the keyboard adapter loaded, P1 O is Select for options and retry.
Read FIGHTER_TECHNIQUES.md for timing, costs and counters.

LOCAL VERSUS PREVIEW: TWO KEYBOARD PLAYERS, ONE GAME WINDOW
Use an mGBA 0.11 development build with raw keyboard scripting.
Open PokemonBattleArena.gba, then Tools > Scripting and load local_versus.lua.
Focus the game window. P1 uses arrows, J/K, U/I and Enter; O is Select/options/retry.
P2 uses WASD, F/G, Q/E and T. Choose Local Versus from the visible mode menu.
Both players press Ready. First to two wins takes the set.
Read LOCAL_VERSUS.md for full setup, controls and preview limitations.

Pokemon Battle Arena v1.3.0-rc.1

Open PokemonBattleArena.gba in a Game Boy Advance emulator such as mGBA.
No compiler, network service or separate commercial ROM is required to play.

GBA CONTROLS (keyboard/controller mappings depend on your emulator)
Left / Right: Move
Up: Jump
Down: Timed squeeze dodge
A: Melee
B: Fire
L held: Block ordinary attacks
R: Super at 100 SP and 25 stamina
Start: Pause
Start/A on title: Visible mode menu
D-pad in menus: Choose a button or fighter
Start/A: Confirm
B: Back
Audio settings are available as a main-menu button; no shoulder shortcut is needed.

AUDIO
Music and sound effects have independent On/Off options.
Settings save when you leave Audio options and survive power-off.
Earlier six- and nine-fighter SRAM records, mastery and audio settings migrate.
The default mix is moderate; emulator/device output volume is separate.

ARCADE
Choose Arcade from the visible mode menu, then difficulty and Pokemon.
Five unique rivals from the other twelve fighters. Two continues.
Results show a mastery increment or the next unfinished goal.
The upcoming/retry rival has one authored trait and counter cue.
A/Start still continues directly; a finished/exhausted run has no next-rival cue.
Woodland, Volcanic, Shoreline, Frostpeak and Ancient Ruins rotate between rivals.
Retries keep the current arena.
Full HP/stamina between fights; draws retry for free.
Pause Rematch costs a continue; changing Pokemon ends the run.
With zero continues Rematch is dimmed and skipped. A finishes an exhausted run.
Records saves clears, no-continue clears and fastest total battle time.
Battle time includes active frames and failed attempts; menus/countdown/recall are excluded.
Unfinished runs do not resume after power-off.

THIRTEEN FIGHTERS
Psyduck: Mind Push adds strong psychic projectile knockback.
Jigglypuff: Float Step gives lighter gravity and longer jumps.
Machop: Heavy Hands adds melee guard-stamina pressure.
Vulpix, Gastly, Riolu and Totodile join the previous roster.
All thirteen fighters have animated movement/attacks, unique themed VFX and sounds.

PRACTICE
Choose Practice from the mode menu
Select in any fighter grid: Open settings directly for that Pokemon
Up/Down in settings: Choose a row. Left/Right: Change its value
B in settings: Return to the same fighter card
A on Fighter Info: Open guide. B: Return to its row
A/Start on grid or value rows: Play. Start also plays from Info
Select in practice: Retry with restored resources/positions and cleared statistics
A fresh action works on emulator frame 8 after reset; Practice KOs restart in 14.
Training options: Free, Block, Attack, Follow-up, Evade Super; Technique for Jigglypuff/Gastly.
Follow-up: Land A, then tap B when FOLLOW B appears.
Evade Super: Let the rival charge, then jump or time Down to avoid its super.
Drills show feedback from actual combat events and never award mastery.

ARENAS AND FIGHTER MASTERY
Quick Battle settings: Difficulty, Location and Fighter Info.
Practice settings: Training, Rival, Location and Fighter Info.
Arcade arena rotation is informational; the cursor skips it.
A check marks the chosen Pokemon, and an outline marks the focused row.
A attacks have a six-frame power-punch animation. Supers have eight-frame auras,
energy-ribbon shots and impact bursts. Ordinary attack timing/base damage and save schema remain compatible.
All arenas share the same floor, hitboxes and combat rules.
Fighter Mastery is a visible main-menu button. Left/Right changes the fighter.
Earn three medals per fighter: 10 damaging follow-up hits, 5 successful super
evasions, and a no-continue Arcade clear at any difficulty. Practice does not count.
Progress saves at the end of a regular round, on Rematch, or when leaving a fight.
Retain your emulator save file. Abrupt power-off during a fight can lose its
unsaved mastery steps. Existing no-continue records already count toward the medal.
Roster badges show the number of medals earned. Mastery/Records link with A.

Clean melee hits can follow with B when the FOLLOW cue appears.
Eevee may also follow with A at close range. One follow-up per sequence.
Supers bypass block and can be evaded with a jump or timed squeeze.

Normal round losses end with a Poke Ball recall. Tap A/Start after the ball
has closed to move to results sooner. Practice retains its quick restart.

Physical hardware and non-Linux rebuilding remain unverified.
Unofficial fan project, not affiliated with Nintendo, Game Freak or The Pokemon Company.
See CREDITS.md and RELEASE_NOTES.md. Editable source is attached to the GitHub Release.
