# Pokémon Battle Arena v1.3.0-rc.1 — Fighter Techniques Preview

Jigglypuff and Gastly gain two new timing choices using their existing controls.

- **Air Brake:** tap Up again during Jigglypuff's descent to slow falling for
  twelve simulation ticks. Costs eight stamina and works once per jump. Landing
  restores its use. It grants no extra height or invulnerability.
- **Shadow Burst:** B casts Gastly's ordinary orb; a fresh B arms it in place
  for eight extra stamina. A twelve-tick outlined warning precedes four active
  ticks. The burst deals ten damage once and can be blocked, jumped, escaped or
  destroyed with a shot. Arming keeps the original firing recovery.
- Fighter Info guides, HUD hints, musical float notes, a purple warning/blast,
  theme-matched sound and two Technique lessons in Practice.
- Both techniques work for either player in one-window Local Versus. The adapter
  adds **P1 O = Select** for setup options and Practice retry.
- CPU fighters request the same buttons using delayed public observations.
  Other fighter mechanics and save schema 4 are preserved.

The player ZIP includes `FIGHTER_TECHNIQUES.md`, the ROM, keyboard adapter,
Local Versus setup, release notes, checksums and credits. Solo techniques use
ordinary GBA bindings. Local Versus requires mGBA 0.11 development with Lua raw
input; stable mGBA 0.10.x lacks that input API.

This is the roadmap's two-fighter preview. Physical keyboard/Qt GUI sessions,
human timing/readability and human matchup balance remain unverified. v1.1.0
remains the stable release. Source validation is in
`docs/TECHNIQUES_TEST_REPORT.md`; the design is `docs/DISTINCTIVE_TECHNIQUES.md`.
No commercial ROM or BIOS is included.
