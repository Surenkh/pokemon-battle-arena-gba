# Pokémon Battle Arena v1.4.0-rc.1 — Rival Cup

Three short Cups give solo sessions a route to finish and a reason to return.
Tempo, Guard and Mirage each have three named rivals, authored locations,
countdown scouting and an optional style goal. All thirteen Pokémon and
three difficulty settings are available.

- Win three fights with one continue. Draws retry for free; pause rematches
  cost a continue. Changing Pokémon or ending a run awards no Cup clear.
- Earn clear, style and perfect achievements; compare the fastest cumulative
  battle time for each Cup/difficulty. Goal progress carries across retries.
- Browse the Cup board's animated rivals, then use the familiar one-page
  fighter grid. The fixed route is labeled and skipped by the options cursor.
- Cup records use two independent verified save copies. Existing Arcade,
  mastery and audio data retain their schema and offsets.
- Combat stats, timings, fighter techniques and CPU tuning retain the
  v1.3.0-rc.1 ruleset. Solo Cup combat can earn normal mastery; Cup clears do
  not award Arcade records. Practice and Local Versus stay separate.

Read [Rival Cup](../RIVAL_CUP_PLAYER_GUIDE.md) and the
[validation report](../RIVAL_CUP_TEST_REPORT.md). The player ZIP includes
RIVAL_CUP.md, the ROM, controls, existing technique/Versus guides and adapter.

This is a preview awaiting human playtesting of pacing, scouting usefulness
and style-goal difficulty. Physical hardware/controller and the two-person
desktop keyboard pilot remain open. No mid-run resume is included.
