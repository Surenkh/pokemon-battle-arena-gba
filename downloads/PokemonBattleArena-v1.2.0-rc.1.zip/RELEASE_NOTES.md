# Pokémon Battle Arena v1.2.0-rc.1 — Local Versus Preview

Two people can choose Pokémon and fight in **one running GBA game and one
emulator window**. This preview uses two keyboard layouts through an
**mGBA 0.11 development** Lua adapter. Stable mGBA 0.10.x lacks the required
raw keyboard scripting API.

- Independent cursors for all thirteen Pokémon on one shared screen, including
  mirror matches. Each player can ready and cancel their own choice.
- All five locations. Player 1 changes location before either player readies;
  the selection locks when a player confirms.
- Separate human input streams, blue P1/gold P2 markers, first-to-two sets,
  correct results for either player, Next Round and Rematch Set.
- Either player can pause. Adapter loss pauses the match and reconnect requires
  a fresh confirmation. Attacks pressed while paused do not leak into combat.
- Existing combat rules, solo progression and schema-4 saves remain compatible.
  Local Versus awards no solo records/mastery and stores no persistent set score.

Extract the complete player ZIP, open `PokemonBattleArena.gba`, then use
**Tools → Scripting** to load `local_versus.lua`. Focus the game window.
**P1:** arrows, J/K, U/I, Enter. **P2:** WASD, F/G, Q/E, T.
Choose **Local Versus** and ready with **J / F**. The ZIP includes a full
`LOCAL_VERSUS.md` setup guide and the exact native-tested adapter.

Validated through one upstream mGBA development core, its actual raw input/Lua
APIs and the shipping script. Physical keyboards, keyboard rollover, Qt
focus/shortcuts, real gamepads and a two-person fun/balance pilot remain open.
This is a release candidate; v1.1.0 remains the stable download.

The player ZIP includes `LOCAL_VERSUS.md`. Source validation is recorded in
`docs/LOCAL_VERSUS_TEST_REPORT.md`.
No commercial ROM or BIOS is included.
