# Pokémon Battle Arena v1.7.0 — Breakaway

Breakaway gives every Pokémon a new way to spend Super Power. During ordinary
hitstun, hold L and tap R to spend **60 SP** on a short backward hop. Save
**100 SP** for a super. The SP gauge marks 60, and **L+R ESCAPE** appears
when the move is available.

The hop travels up to 24 pixels over eight simulation ticks, followed by
twelve ticks of recovery. Walls limit travel. An attacker can chase and punish
the recovery after post-hit protection expires. The escape window comes from
taking an ordinary hit. Guard break and super hitstun have their own reactions.

Open **Practice → Breakaway** with any Pokémon. Let the rival hit you, then
hold L and tap R when prompted. Select resets the attempt. In Local Versus,
Player 1 holds U and taps I, and Player 2 holds Q and taps E.

The 60 SP cost and recovery timing are starting values for human playtesting.
