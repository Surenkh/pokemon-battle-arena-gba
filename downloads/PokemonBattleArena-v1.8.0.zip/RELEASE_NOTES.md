# Pokémon Battle Arena v1.8.0 — Combat Motion

Every Pokémon now performs a compact, animated Down dodge with a moving wind
trail. The original pose proportions are retained, and the dodge keeps its
existing timing, stamina cost and counters. Squirtle's directional Shell Roll
remains available.

When two normal projectiles meet, their elemental colors burst together with
a new clash sound. An original battle theme, **Arena Momentum**, changes to a
more intense section when either fighter reaches one-quarter health. Music and
sound effects have independent on/off controls.

Super KOs and melee KOs that punish recovery now show their own finish cue
before the Poké Ball recall. These effects work in solo and Local Versus.

The game uses the existing GBA controls. For two players, extract the player ZIP
and follow the included Local Versus guide for the mGBA 0.11 development adapter.
Human playtesting and physical GBA hardware checks remain open.
