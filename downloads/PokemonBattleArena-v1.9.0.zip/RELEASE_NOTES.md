# Pokémon Battle Arena v1.9.0 — Combat Dynamics

Fights offer more defensive choices and a chance to regain space:

- Normal projectiles continue through one another after a clash. Both lose half
  their current damage (rounded up, minimum one); the elemental burst remains.
- Jump costs 10 stamina instead of 18, and the stationary Down dodge costs 6
  instead of 12. Squirtle's directional Shell Roll costs 14 stamina in total.
- Hold L and tap away from your opponent to backstep for 6 stamina. It is
  interruptible, has recovery and can be queued near the end of blockstun.
- A blocked melee attack pushes fighters apart. A blocked or missed melee
  attack takes four extra simulation ticks to recover; a clean hit retains its
  normal timing. CPU opponents can also use backstep under pressure.

Super projectiles and Gastly's armed Shadow Orb retain their existing collision
rules. All solo modes and Local Versus use the same combat rules. Extract the
player ZIP for the game, controls and two-player adapter.

The numbers are an initial balance pass. Human matches, physical keyboards and
GBA hardware still need testing to assess readability, counterplay and fairness.
