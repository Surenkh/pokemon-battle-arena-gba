# Sources and artwork

The six main roster sprites are existing Generation III Emerald Pokémon battle sprites, retrieved through the [PokéAPI sprites repository](https://github.com/PokeAPI/sprites). They were cropped, aligned to a common 64 × 64 transparent canvas and mirrored where appropriate. They are sourced game assets, not newly generated character drawings.

The woodland arena and the bonus Charmander and Bulbasaur eight-pose sheets were created with built-in image generation. Original generated PNGs and prompts are included.

## Main sprite source files

- pikachu: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/25.png
- charmander: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/4.png
- squirtle: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/7.png
- bulbasaur: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/1.png
- eevee: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/133.png
- meowth: https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-iii/emerald/52.png

Retrieved: 2026-10-27.

## Game screens update

The six-Pokémon title ensemble is newly generated artwork. Its original PNG is `sources/title_ensemble.png`; its prompt is in `screens/ARTWORK_PROMPT.json`. The screen layouts, bitmap UI font, UI buttons, interface rendering and animation are implemented in code. The screen background layers reuse the generated woodland arena.

## Movement update

Runtime animation credits and original source records: [animations/CREDITS.md](animations/CREDITS.md).

## Elemental attack update

The new projectiles, supers, muzzle flashes, hit effects and guard effects are pixel-authored by project code in tools/elemental_fx.cjs. No additional external character artwork is introduced.

## v0.7 original presentation assets

Leaflight Circuit (title/menu music), three tracker wavetables and fourteen new menu/round/recall/result cues are original deterministic compositions/synthesis authored for this project in tools/generate_presentation_audio.py. They use no sampled Pokémon recording or existing song. The module, source score and generation metadata are included.

The new Poké Ball poses, recall beam and seal glints are original native pixel-art implementations in tools/round_fx.cjs. Pokémon and Poké Ball names/designs belong to their respective owners; the project remains an unofficial fan work. Existing character artwork and engine notices above still apply.


## v0.9 original stage and mastery artwork

Volcanic/shoreline scenery and the mastery badge atlas are original deterministic
pixel artwork authored in `tools/arena_art.cjs`. Native HUD and mastery/menu
backgrounds are composed by `tools/convert_assets.cjs` using the existing project
UI renderer. These additions introduce no third-party artwork or downloads.

## v1.0 RC2 expansion

The four added Pokémon retain the credited CHUNSOFT artwork and upstream records
in `animations/`. Frostpeak and Ancient Ruins are original deterministic pixel
art in `tools/arena_art.cjs`. New elemental effects and combat sounds are authored
by project code with no new sampled recordings. Existing rights/notices apply.

## v1.1 Selection & Power

The compact chooser reuses the existing credited body artwork. The tiny bitmap
labels, selection backplates, arena previews, energy ribbons, charge rings,
power-punch and super-impact sprites are authored in project code. No new
third-party art, recordings or synthesized body poses are introduced.
